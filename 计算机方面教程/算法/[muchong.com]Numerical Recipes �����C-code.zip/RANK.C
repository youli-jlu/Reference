void rank(n,indx,irank)
int indx[],irank[],n;
{
	int j;

	for (j=1;j<=n;j++) irank[indx[j]]=j;
}
